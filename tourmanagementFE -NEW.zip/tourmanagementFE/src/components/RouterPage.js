import React from  'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import AdminDashboard from './admin/AdminDashboard';
import AdminBookings from './admin/AdminBookings';
import TourList from './admin/TourList';
import Login from './Login';
import Registration from './Registration';
import Dashboard from './users/Dashboard';
import MyBookings from './users/MyBookings';
import AllTours from './users/AllTours';



export default function RouterPage(){
    
    return(
        <Router>
            <Routes>
                <Route exact path='/' element={ <Login /> } />
                <Route path='/registration' element={ <Registration /> } />
                <Route path='/dashboard' element={ <Dashboard /> } />                
                <Route path='/myorders' element={ <MyBookings /> } />
                <Route path='/admindashboard' element={ <AdminDashboard /> } />
                <Route path='/allbookings' element={ <AdminBookings /> } />
                <Route path='/tour' element={ <TourList /> } />
                <Route path='/AllTours' element={ <AllTours/> } />
                
            
            </Routes>
        </Router>
    )
}