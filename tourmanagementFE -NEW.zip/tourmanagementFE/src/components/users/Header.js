import React, {useState,Fragment,useEffect} from  'react';
import { Link } from "react-router-dom";
import './Header.css'

export  default function Header(){    

    const [username, setUserName] = useState("");

    useEffect(() => {
      setUserName(localStorage.getItem("username"));
    }, []);
  
    const logout = (e) => {
      e.preventDefault();
      localStorage.removeItem("username");
      window.location.href = "/";
    };
    const login = (e) => {
      e.preventDefault();
      localStorage.removeItem("username");
      window.location.href = "/login";
    };
  
    return (
      <Fragment>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">          
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
  
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul 
            className={`navbar-nav mr-auto ${username === '' || username === null ? 'hiddenNav' : ''}`} >
              <li className="nav-item active">
              <Link to="/dashboard"  className="nav-link" >
                  Welcome <span className="sr-only">(current)</span>
                  ( {username} )
                  </Link>
              </li>
              <li className="nav-item">
                <Link to="/alltours" className="nav-link">
                  Book New Tour
                </Link>
              </li> 
              <li className="nav-item">
                <Link to="/myorders" className="nav-link">
                  My Bookings
                </Link>
              </li>      
                      
            </ul>
            <form className="form-inline my-2 my-lg-0">
             
               <button
               className="btn btn-outline-success my-2 my-sm-0"
               type="submit"
               onClick={(e) => logout(e)}
             >
               Logout
             </button>
             

            </form>
          </div>
        </nav>
        
      </Fragment>
    );
}