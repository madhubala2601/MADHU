import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import Header from "./Header";
import { baseUrl } from "../constants";

export default function AllTours() {
  const [tourData, setTourData] = useState([]);

  const [tourId, setTourId] = useState("");
  const [bookingDate, setBookingDate] = useState("");
  const [totalPeople, setTotalPeople] = useState("");

  useEffect(() => {
    getTours();
  }, []);


  const getTours = () => {
    const url = `${baseUrl}/api/User/tour`;
    axios
      .get(url)
      .then((result) => {
        const data = result.data;
        if (data.statusCode === 200) {
          setTourData(data.listTours);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const fillTourdetails = (type, id, value) => {

    if (tourId === "") {
      setTourId(id);
    }
    else {
      if (tourId !== id) {
        alert('Kindly book single tour at a time. Click ok to Refresh the page.')
        window.location.reload();
      }
    }
    
    setTourId(id);
    if (type === 'date')
      setBookingDate(value);
    if (type === 'people')
      setTotalPeople(value);

  }

  const handleSave = (e) => {
    let error = "";
    if (tourId === "")
      error += "Tour id ";
    if (bookingDate === "")
      error += "Booking date "
    if (totalPeople === "")
      error += "People "

    if (error.length > 0) {
      error += "are required."
      alert(error);
      return false;
    }

    e.preventDefault();
    const url = `${baseUrl}/api/User/booking`;
    const data = {
      UserID: localStorage.getItem("loggedUserId"),
      TourId: tourId.toString(),
      BookingDate: bookingDate,
      TotalPeople: totalPeople
    };

    axios
      .post(url, data)
      .then((result) => {
        clear();
        const dt = result.data;
        alert(dt.statusMessage);
        window.location.reload();
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const clear = () => {
    setTourId("");
    setBookingDate("");
    setTotalPeople("")
  };

  return (
    <Fragment>
      <Header />
      <br></br>
      <form style={{ display: "none" }}>
        <div
          className="form-row"
          style={{ width: "80%", backgroundColor: "white", margin: " auto" }}
        >
          <div className="form-group col-md-12">
            <h3>Book New Tour</h3>
          </div>
          <div className="form-group col-md-3">
            <select
              onChange={(e) => setTourId(e.target.value)}
              value={tourId} className="form-control">
              <option value="0">-Select Tour-</option>
              {tourData.map((val, index) => {
                return (
                  <option key={index} value={val.id}>{val.name}</option>
                );
              })}
            </select>
          </div>

          <div className="form-group col-md-3">
            <input
              type="date"
              onChange={(e) => setBookingDate(e.target.value)}
              placeholder="Passwprd"
              className="form-control"
              required
              value={bookingDate}
            />
          </div>

          <div className="form-group col-md-3">
            <input
              type="text"
              onChange={(e) => setTotalPeople(e.target.value)}
              placeholder="Enter Total People"
              className="form-control"
              required
              value={totalPeople}
            />
          </div>
          <div className="form-group col-md-3">
            <button className="btn btn-primary" onClick={(e) => handleSave(e)}>Book New Tour</button>
          </div>
        </div>
      </form>
      <br></br>

      <div
          class="form-row"
          style={{ width: "80%", backgroundColor: "white", margin: " auto" }}
        >
          <div class="form-group col-md-12">
            <h3>Book a New Tour</h3>
          </div>
          <div className="form-group col-md-3">
            <select
            onChange={(e) => setTourId(e.target.value)}
            value={tourId}  className="form-control">
              <option value="0">-Select Tour-</option>
              {tourData.map((val, index) => {
              return (
                <option key={index} value={val.id}>{val.name}</option>
              );
            })}
            </select>           
          </div>
          <div className="form-group col-md-3">
            <input
              type="date"
              onChange={(e) => setBookingDate(e.target.value)}
              placeholder="Passwprd"
              className="form-control"
              required
              value={bookingDate}
            />
          </div>
          <div className="form-group col-md-3">
            <input
              type="text"
              onChange={(e) => setTotalPeople(e.target.value)}
              placeholder="Enter Total People"
              className="form-control"
              required
              value={totalPeople}
            />
          </div>
          
                 
          <div className="form-group col-md-3">
            <button className="btn btn-primary" onClick={(e)=> handleSave(e)}>Book Tour</button>
          </div>
        </div>
        <br></br>
      
        <iframe width="1000" height="400" src="https://www.youtube.com/embed/IgAnj6r1O48?si=ggNoc6dslRpr90A0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen> </iframe>
      
      <div className="container">
        <div className="row">
          {tourData && tourData.length > 0 ?
            tourData.map((tour, index) => {
              return (
                <div className="col-sm-3" key={index}>
                  <div className="card-deck">
                    <div className="card text-white bg-info mb-3">
                      <div className="card-body">
                        <h5 className="card-title">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-bookmark-check" viewBox="0 0 16 16">
                            <path fillRule="evenodd" d="M10.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z" />
                            <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z" />
                          </svg> {' : '}
                          {tour.name}</h5>
                        <p className="card-text">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-geo-alt" viewBox="0 0 16 16">
                            <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A31.493 31.493 0 0 1 8 14.58a31.481 31.481 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94zM8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10z" />
                            <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                          </svg> {' : '}
                          {tour.location}</p>
                        <p className="card-text">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-currency-rupee" viewBox="0 0 16 16">
                            <path d="M4 3.06h2.726c1.22 0 2.12.575 2.325 1.724H4v1.051h5.051C8.855 7.001 8 7.558 6.788 7.558H4v1.317L8.437 14h2.11L6.095 8.884h.855c2.316-.018 3.465-1.476 3.688-3.049H12V4.784h-1.345c-.08-.778-.357-1.335-.793-1.732H12V2H4v1.06Z" />
                          </svg>  {' : '}
                          {tour.price}</p>
                          
                          
                       
                       
                       
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
            : 'LOADING...'}
        </div></div>

        
        
    </Fragment>
  );
}
