import React, { Fragment, useEffect, useState } from "react";
import {baseUrl} from '../constants';
import axios from "axios";
import Header from "./Header";

export default function Profile() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    getData();
  }, []);

  const getData = () => {
    const data = {
      Email: localStorage.getItem("username"),
    };
    const url = `${baseUrl}/api/Users/viewUser`;
    axios
      .post(url, data)
      .then((result) => {
        const data = result.data;
        if (data.statusCode === 200) {
          setFirstName(data.user.firstName);
          setLastName(data.user.lastName);
          setEmail(data.user.email);
          setPassword(data.user.password);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Fragment>
      <Header />
      <br></br>
      <form>
        <div
          class="form-row"
          style={{ width: "80%", backgroundColor: "purple", margin: " auto" }}
        >
          <div class="form-group col-md-12">
            <h3>My Profile</h3>
          </div>
          <div className="form-group col-md-6">
            <input
              type="text"
              onChange={(e) => setFirstName(e.target.value)}
              placeholder="First Name"
              className="form-control"
              required
              value={firstName}
              disabled
            />
          </div>
          <div className="form-group col-md-6">
            <input
              type="text"
              onChange={(e) => setLastName(e.target.value)}
              placeholder="Last Name"
              className="form-control"
              required
              value={lastName}
              disabled
            />
          </div>

          <div className="form-group col-md-6">
            <input
              type="text"
              className="form-control"
              id="validationTextarea"
              placeholder="Email"
              onChange={(e) => setEmail(e.target.value)}
              required
              value={email}
              disabled
            ></input>
          </div>
          <div className="form-group col-md-6">
            <input
              type="text"
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Passwprd"
              className="form-control"
              required
              value={password}
            />
          </div>          
        </div>
      </form>
     
    </Fragment>
  );
}
