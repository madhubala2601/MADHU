import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import Header from "./Header";
import { baseUrl } from "../constants";

export default function Booknewtour() {
  const [data, setData] = useState([]);
  const [tourData, setTourData] = useState([]);

  const [tourId, setTourId] = useState("");
  const [bookingDate, setBookingDate] = useState("");
  const [totalPeople, setTotalPeople] = useState("");

  useEffect(() => {
    getData();
    getTours();
  }, []);

  const getData = () => {
    const data = {
      Id: localStorage.getItem("loggedUserId")
    };
    const url = `${baseUrl}/api/User/bookingList`;
    axios
      .post(url, data)
      .then((result) => {
        const data = result.data;
        if (data.statusCode === 200) {
          console.log(data.listBookings)
          setData(data.listBookings)
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const getTours = () => {
    const url = `${baseUrl}/api/User/tour`;
    axios
      .get(url)
      .then((result) => {
        const data = result.data;
        if (data.statusCode === 200) {
          setTourData(data.listTours);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleSave = (e) => {

    let error = '';
    if (tourId === '')
      error = error + 'Tour ,';
    if (bookingDate === '')
      error = error + 'Booking Date ,';

    if (error.length > 0) {
      error = error.substring(0, error.length - 1) + 'can not be blank';
      alert(error);
      return;
    }

    e.preventDefault();
    const url = `${baseUrl}/api/User/booking`;
    const data = {
      UserID: localStorage.getItem("loggedUserId"),
      TourId: tourId,
      BookingDate: bookingDate,
      TotalPeople : totalPeople
    };

    axios
      .post(url, data)
      .then((result) => {
        clear();
        getData();
        const dt = result.data;
        alert(dt.statusMessage);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleDelete = (e, id) => {

    e.preventDefault();
    const url = `${baseUrl}/api/User/deleteBooking`;
    const data = {
      Id: id
    };

    axios
      .post(url, data)
      .then((result) => {
        clear();
        getData();
        const dt = result.data;
        alert(dt.statusMessage);
        getData();
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const clear = () => {
    setTourId("");
    setBookingDate("");
    setTotalPeople("")
  };

  return (
    <Fragment>
      <Header />
      <br></br>
      <form>
        <div
          class="form-row"
          style={{ width: "80%", backgroundColor: "pink", margin: " auto" }}
        >
          <div class="form-group col-md-12">
            <h3>Book a New Tour</h3>
          </div>
          <div className="form-group col-md-3">
            <select
              onChange={(e) => setTourId(e.target.value)}
              value={tourId} className="form-control">
              <option value="0">-Select Tour-</option>
              {tourData.map((val, index) => {
                return (
                  <option key={index} value={val.id}>{val.name}</option>
                );
              })}
            </select>
          </div>
          
          

          <div className="form-group col-md-3">
            <input
              type="date"
              onChange={(e) => setBookingDate(e.target.value)}
              placeholder="Passwprd"
              className="form-control"
              required
              value={bookingDate}
            />
          </div>

          <div className="form-group col-md-3">
            <input
              type="text"
              onChange={(e) => setTotalPeople(e.target.value)}
              placeholder="Enter Total People"
              className="form-control"
              required
              value={totalPeople}
            />
              
          </div>
          <div className="form-group col-md-3">
            <button className="btn btn-primary" onClick={(e) => handleSave(e)}>Book New Tour</button>
          </div>
        </div>
        <img
                          src="../tirumala.png"
                          className="img-fluid"
                          alt="Sample image"
                        />
                         <img
                          src="../munnar.png"
                          className="img-fluid"
                          alt="Sample image"
                        />
                         <img
                          src="../horsleyhills.png"
                          className="img-fluid"
                          alt="Sample image"
                        />
                         <img
                          src="../mybooking.jpg"
                          className="img-fluid"
                          alt="Sample image"
                        /> <img
                        src="../mybooking.jpg"
                        className="img-fluid"
                        alt="Sample image"
                      /> <img
                      src="../mybooking.jpg"
                      className="img-fluid"
                      alt="Sample image"
                    /> 
      </form>
      <br></br><br></br>
     

    </Fragment>
  );
}
  

