import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import Header from "./Header";
import { baseUrl } from "../constants";



export default function MyBookings() {
  const [data, setData] = useState([]);
  const [tourData, setTourData] = useState([]);

  const [tourId, setTourId] = useState("");
  const [bookingDate, setBookingDate] = useState("");
  const [totalPeople, setTotalPeople] = useState("");
 

  useEffect(() => {
    getData();   
  }, []);

  const getData = () => {
    const data = {
      Id: localStorage.getItem("loggedUserId")
    };
    const url = `${baseUrl}/api/User/bookingList`;
    axios
      .post(url, data)
      .then((result) => {
        const data = result.data;
        if (data.statusCode === 200) {
          console.log(data.listBookings)
          setData(data.listBookings)
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  
  const handleDelete = (e, id) => {

    e.preventDefault();
    const url = `${baseUrl}/api/User/deleteBooking`;
    const data = {
      Id: id
    };
    

    axios
      .post(url, data)
      .then((result) => {
       
        getData();
        const dt = result.data;
        alert(dt.statusMessage);
        getData();
      })
      .catch((error) => {
        console.log(error);
      });
  };


  return (
    <Fragment>
      <Header />
      
    
      <div class="form-group col-md-12">
        <h3>My Bookings</h3>
      </div>
      
      
      
      {data ? (
        <div className="container">
        <div className="row">
          {data && data.length > 0 ?
            data.map((tour, index) => {
              return (
                <div className="col-sm-3" key={index}>
                  <div className="card-deck">
                    <div className="card text-white bg-info mb-3">
                      <div className="card-body">
                        <h5 className="card-title">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-bookmark-check" viewBox="0 0 16 16">
                            <path fillRule="evenodd" d="M10.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z" />
                            <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z" />
                          </svg> {' : '}
                          {tour.tourName}</h5>
                         
                          <p className="card-text">
                           <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-envelope-fill" viewBox="0 0 16 16">
                           <path d="M8 .5a7.5 7.5 0 0 1 7.5 7.5c0 4.142-3.358 7.5-7.5 7.5S.5 12.642.5 8.5A7.5 7.5 0 0 1 8 .5zM1.293 4.293a1 1 0 0 1 1.414-1.414L8 7.586l5.293-5.293a1 1 0 1 1 1.414 1.414L8 10.414l-6.707-6.707a1 1 0 0 1 0-1.414z"/>
                           </svg> {' : '} 
                          {tour.email}</p>

                          <p className="card-text">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-people-fill" viewBox="0 0 16 16">
                            <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7Zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm-5.784 6A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216ZM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" />
                          </svg> {' : '}
                          {tour.userName}</p>

                          <p className="card-text">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-calendar-check-fill" viewBox="0 0 16 16">
                            <path d="M4 .5a.5.5 0 0 0-1 0V1H2a2 2 0 0 0-2 2v1h16V3a2 2 0 0 0-2-2h-1V.5a.5.5 0 0 0-1 0V1H4V.5zM16 14V5H0v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2zm-5.146-5.146-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L7.5 10.793l2.646-2.647a.5.5 0 0 1 .708.708z" />
                          </svg> {' : '}
                          {tour.bookingDate}</p>

                          <p className="card-text">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-geo-alt" viewBox="0 0 16 16">
                            <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A31.493 31.493 0 0 1 8 14.58a31.481 31.481 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94zM8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10z" />
                            <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                          </svg> {' : '}
                          {tour.location}</p>
                          
                          <p className="card-text">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-people-fill" viewBox="0 0 16 16">
                            <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7Zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm-5.784 6A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216ZM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" />
                          </svg> {' : '}
                          {tour.totalPeople}</p>

                          <p className="card-text">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-currency-rupee" viewBox="0 0 16 16">
                            <path d="M4 3.06h2.726c1.22 0 2.12.575 2.325 1.724H4v1.051h5.051C8.855 7.001 8 7.558 6.788 7.558H4v1.317L8.437 14h2.11L6.095 8.884h.855c2.316-.018 3.465-1.476 3.688-3.049H12V4.784h-1.345c-.08-.778-.357-1.335-.793-1.732H12V2H4v1.06Z" />
                          </svg>  {' : '}
                          {tour.price}</p>
                          <button className="btn btn-dark" style={{ marginLeft: "10px" }} onClick={(e) => handleDelete(e,tour.id)}>cancelTour</button>
                          
                       
                       
                       
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
            : 'LOADING...'}
        </div></div>
        
      ) : (
        "No data found"
      )}
      
      
    </Fragment>
  );
}
