import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import Header from "./AdminHeader";
import { baseUrl } from "../constants";


export default function AdminBookings() {
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = () => {
    const data = {
      Id : 0
    };
    const url = `${baseUrl}/api/User/bookingList`;
    axios
      .post(url, data)
      .then((result) => {
        const data = result.data;
        if (data.statusCode === 200) {
          setData(data.listBookings)
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Fragment>
      <Header />
      <br></br>
       <br></br>
      <div class="form-group col-md-12">
        <h3>All Bookings</h3>
      </div>
      
     
      {data ? (
        <table
          className="table stripped table-hover mt-4"
          style={{  width: "80%", margin: "0 auto",backgroundImage:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7S0uI7M2BHh1nbjn_wGeEb8DQ5LSSy0BXLA&usqp=CAU" }}
          
        >
          <thead className="thead-white">
            <tr>
              <th scope="col">Sno</th>
              <th scope="col">Tour name</th>
              <th scope="col">Price</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Location</th>
              <th scope="col">Date</th>
              <th scope="col">Status</th>
            </tr>
          </thead>
          <tbody>
            {data.map((val, index) => {
              return (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>                  
                  <td>{val.tourName}</td>
                  <td>{val.price}</td>
                  <td>{val.userName}</td>
                  <td>{val.email}</td>
                  <td>{val.location}</td>
                  <td>{val.bookingDate}</td>
                  <td>{val.status === 1 ? 'Booked' : 'Cancelled'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      ) : (
        "No data found"
      )}
      
    </Fragment>
  );
}

