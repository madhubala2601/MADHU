﻿using EventManagementBE.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using tourmanagementBE.Models;

namespace tourmanagementBE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public AdminController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        [Route("addTour")]
        public Response addTour(Tour tour)
        {
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DBCS").ToString());
            Response response = dal.tour(tour, connection, "ADD");
            return response;
        }

        [HttpPost]
        [Route("deleteTour")]
        public Response deleteTour(Tour tour)
        {
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DBCS").ToString());
            Response response = dal.tour(tour, connection, "DELETE");
            return response;
        }

        [HttpPost]
        [Route("updateTour")]
        public Response updateTour(Tour tour)
        {
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DBCS").ToString());
            Response response = dal.tour(tour, connection, "UPDATE");
            return response;
        }
    }
}
