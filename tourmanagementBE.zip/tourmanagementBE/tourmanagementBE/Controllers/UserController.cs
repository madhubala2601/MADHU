﻿using EventManagementBE.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using tourmanagementBE.Models;

namespace tourmanagementBE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public UserController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        [Route("registration")]
        public Response register(User user)
        {
            Response response = new Response();
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DBCS").ToString());
            response = dal.register(user, connection);
            return response;
        }

        [HttpPost]
        [Route("login")]
        public Response login(User user)
        {
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DBCS").ToString());
            Response response = dal.login(user, connection);
            return response;
        }

        [HttpGet]
        [Route("tour")]
        public Response tour()
        {
            DAL dal = new DAL();
            Tour tour = new Tour();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DBCS").ToString());
            Response response = dal.tour(tour, connection, "GETALL");
            return response;
        }

        [HttpPost]
        [Route("booking")]
        public Response bookings(Bookings bookings)
        {
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DBCS").ToString());
            Response response = dal.bookings(bookings, connection);
            return response;
        }

        [HttpPost]
        [Route("bookingList")]
        public Response bookingList(User user)
        {
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DBCS").ToString());
            Response response = dal.bookingList(user, connection);
            return response;
        }

        [HttpPost]
        [Route("deleteBooking")]
        public Response deleteBooking(Bookings bookings)
        {
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("DBCS").ToString());
            Response response = dal.deleteBooking(bookings, connection);
            return response;
        }
    }
}
