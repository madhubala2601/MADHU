﻿namespace tourmanagementBE.Models
{
    public class Response
    {
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }
        public Bookings bookings { get; set; }
        public List<Bookings> listBookings { get; set; }

        public Tour tour { get; set; }
        public List<Tour> listTours { get; set; }
        public User user { get; set; }        

    }
}
