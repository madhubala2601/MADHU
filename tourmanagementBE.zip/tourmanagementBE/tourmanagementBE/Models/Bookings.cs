﻿namespace tourmanagementBE.Models
{
    public class Bookings
    {
        public int Id { get; set; }
        public string UserID { get; set; }
        public string TourID { get; set; }
        public string BookingDate { get; set; }

        public string TourName { get; set; }
        public string UserName { get; set; }

        public string Email { get; set; }
        public string Price { get; set; }
        public string Location { get; set; }
        public string TotalPeople { get; set; }
        public int Status { get; set; }
    }
}
