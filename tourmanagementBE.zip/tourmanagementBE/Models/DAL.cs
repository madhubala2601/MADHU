﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using tourmanagementBE.Models;

namespace EventManagementBE.Models
{
    public class DAL
    {
        public Response register(User users, SqlConnection connection)
        {
            Response response = new Response();
            SqlCommand cmd = new SqlCommand("sp_register", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", 0);
            cmd.Parameters.AddWithValue("@FirstName", users.FirstName);
            cmd.Parameters.AddWithValue("@LastName", users.LastName);
            cmd.Parameters.AddWithValue("@Email", users.Email);
            cmd.Parameters.AddWithValue("@Password", users.Password);
            cmd.Parameters.AddWithValue("@Type", "ADD");
            connection.Open();
            int i = cmd.ExecuteNonQuery();
            connection.Close();
            if (i > 0)
            {
                response.StatusCode = 200;
                response.StatusMessage = "User registered successfully";
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "User registration failed";
            }
            return response;
        }       
        public Response login(User users, SqlConnection connection)
        {
            SqlDataAdapter da = new SqlDataAdapter("sp_login", connection);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@Email", users.Email);
            da.SelectCommand.Parameters.AddWithValue("@Password", users.Password);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Response response = new Response();
            User user = new User();
            if (dt.Rows.Count > 0)
            {
                response.StatusCode = 200;
                response.StatusMessage = "User is valid";
                user.Id = Convert.ToInt32(dt.Rows[0]["ID"]);
                user.Email = Convert.ToString(dt.Rows[0]["Email"]);
                response.user = user;
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "User is invalid";
                response.user = null;
            }
            return response;
        }
        public Response bookings(Bookings bookings, SqlConnection connection)
        {
            Response response = new Response();
            SqlCommand cmd = new SqlCommand("sp_Bookings", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", bookings.UserID);
            cmd.Parameters.AddWithValue("@TourID", bookings.TourID);
            cmd.Parameters.AddWithValue("@BookingDate", bookings.BookingDate);
            cmd.Parameters.AddWithValue("@TotalPeople", bookings.TotalPeople);
            cmd.Parameters.AddWithValue("@Type", "ADD");
            connection.Open();
            int i = cmd.ExecuteNonQuery();
            connection.Close();
            if (i > 0)
            {
                response.StatusCode = 200;
                response.StatusMessage = "Tour booked successfully";
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "Tour could not be booked";
            }
            return response;
        }
        public Response bookingList(User user, SqlConnection connection)
        {
            SqlDataAdapter da = new SqlDataAdapter("sp_Bookings", connection);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@UserID", user.Id);
            da.SelectCommand.Parameters.AddWithValue("@Type", "GET");
            DataTable dt = new DataTable();
            da.Fill(dt);
            Response response = new Response();
            List<Bookings> listBookings = new List<Bookings>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Bookings objBookings = new Bookings();
                    objBookings.Id = Convert.ToInt32(dt.Rows[i]["ID"]);
                    objBookings.TourName = Convert.ToString(dt.Rows[i]["TourName"]);
                    objBookings.UserName = Convert.ToString(dt.Rows[i]["UserName"]);
                    objBookings.Location = Convert.ToString(dt.Rows[i]["Location"]);
                    objBookings.Price = Convert.ToString(dt.Rows[i]["Price"]);
                    objBookings.BookingDate = Convert.ToString(dt.Rows[i]["BookingDate"]);
                    objBookings.TotalPeople = Convert.ToString(dt.Rows[i]["TotalPeople"]);
                    listBookings.Add(objBookings);
                }
                if (listBookings.Count > 0)
                {
                    response.StatusCode = 200;
                    response.StatusMessage = "Data found";
                    response.listBookings = listBookings;
                }
                else
                {
                    response.StatusCode = 100;
                    response.StatusMessage = "No data found";
                    response.listBookings = null;
                }
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "No data found";
                response.listBookings = null;
            }
            return response;
        }
        public Response tour(Tour tour, SqlConnection connection, string type)
        {
            Response response = new Response();
            List<Tour> listTours = new List<Tour>();
            if (type == "ADD" || type == "UPDATE" || type == "DELETE")
            {                
                SqlCommand cmd = new SqlCommand("sp_Tour", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", tour.Id);
                cmd.Parameters.AddWithValue("@Name", tour.Name);
                cmd.Parameters.AddWithValue("@Location", tour.Location);
                cmd.Parameters.AddWithValue("@Price", tour.Price);
                cmd.Parameters.AddWithValue("@Type", type);
                connection.Open();
                int i = cmd.ExecuteNonQuery();
                connection.Close();
                if (i > 0)
                {
                    response.StatusCode = 200;
                    response.StatusMessage = "Operation executed successfully";
                }
                else
                {
                    response.StatusCode = 100;
                    response.StatusMessage = "try after sometime";
                }
            }
            else
            {
                SqlDataAdapter da = new SqlDataAdapter("sp_Tour", connection);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.AddWithValue("@ID", tour.Id);
                da.SelectCommand.Parameters.AddWithValue("@Type", type);
                DataTable dt = new DataTable();
                da.Fill(dt);               
                if (dt.Rows.Count > 0)
                {
                    if (type == "GETALL")
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            Tour objTour = new Tour();
                            objTour.Id = Convert.ToInt32(dt.Rows[i]["ID"]);
                            objTour.Name = Convert.ToString(dt.Rows[i]["Name"]);
                            objTour.Price = Convert.ToString(dt.Rows[i]["Price"]);
                            objTour.Location = Convert.ToString(dt.Rows[i]["Location"]);
                            listTours.Add(objTour);
                        }
                        if (listTours.Count > 0)
                        {
                            response.StatusCode = 200;
                            response.StatusMessage = "Data found";
                            response.listTours = listTours;
                        }
                        else
                        {
                            response.StatusCode = 100;
                            response.StatusMessage = "No data found";
                            response.listTours = null;
                        }
                    }
                    else
                    {
                        Tour objTour = new Tour();
                        objTour.Id = Convert.ToInt32(dt.Rows[0]["ID"]);
                        objTour.Name = Convert.ToString(dt.Rows[0]["TourName"]);
                        objTour.Price = Convert.ToString(dt.Rows[0]["UserName"]);
                        objTour.Location = Convert.ToString(dt.Rows[0]["Location"]);
                        response.tour = objTour;
                    }
                }
                else
                {
                    response.StatusCode = 100;
                    response.StatusMessage = "No data found";
                    response.listBookings = null;
                }
            }
            return response;
        }
        public Response deleteBooking(Bookings bookings, SqlConnection connection)
        {
            Response response = new Response();
            SqlCommand cmd = new SqlCommand("sp_Bookings", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", bookings.Id);
            cmd.Parameters.AddWithValue("@Type", "DELETE");
            connection.Open();
            int i = cmd.ExecuteNonQuery();
            connection.Close();
            if (i > 0)
            {
                response.StatusCode = 200;
                response.StatusMessage = "Tour cancelled successfully";
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "Tour could not be cancelled";
            }
            return response;
        }

    }
}
